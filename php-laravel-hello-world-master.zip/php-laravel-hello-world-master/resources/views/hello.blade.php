<html>
  <body>
    <h1>/hello/</h1>
    <p>{{ $message }}</p>
  </body>
</html>

