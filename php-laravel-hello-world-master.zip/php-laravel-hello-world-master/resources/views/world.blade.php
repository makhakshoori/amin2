<html>
  <body>
    <h1>/world/</h1>
    <p>{{ $message }}</p>
  </body>
</html>

